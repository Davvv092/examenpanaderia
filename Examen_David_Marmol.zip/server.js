const express = require('express');
const { Client } = require('pg');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cors());

const client = new Client({
  user: 'postgres',
  host: 'localhost',
  database: 'pan', // Cambiado a 'pan' para reflejar la base de datos correcta
  password: '1234',
  port: 5432,
});

client.connect()
  .then(() => console.log('Conexión a PostgreSQL exitosa'))
  .catch(err => console.error('Error al conectar a PostgreSQL', err));

app.post('/enviarEvento', (req, res) => {
  console.log('Cuerpo de la solicitud:', req.body);

  const { nombre, fecha, producto, descripcion, epromocion } = req.body;

  const query = 'INSERT INTO eventos(nombre, fecha, producto, detalle,promocion) VALUES($1, $2, $3, $4, $5)';
  const values = [nombre, fecha, producto, descripcion,epromocion];

  client.query(query, values)
    .then(() => res.status(200).send({ message: 'Evento enviado correctamente' }))
    .catch(err => {
      console.error('Error al enviar el evento:', err);
      res.status(500).send(`Error interno del servidor: ${err.message}`);
    });
});

app.get('/verEventos', (req, res) => {
  const query = 'SELECT id, nombre, fecha, producto, detalle FROM eventos';

  client.query(query)
    .then(data => {
      res.status(200).json({ eventos: data.rows });
    })
    .catch(err => {
      console.error('Error al obtener los eventos:', err);
      res.status(500).send('Error interno del servidor');
    });
});

app.put('/cambiarEstadoPromocion/:id', (req, res) => {
  const idPromocion = req.params.id;
  const nuevoEstado = req.body.estado; // Suponiendo que el nuevo estado se envía en el cuerpo de la solicitud

  // Validar que el nuevo estado sea válido (por ejemplo, 'si' o 'no')
  if (nuevoEstado !== 'si' && nuevoEstado !== 'no') {
    return res.status(400).json({ error: 'El estado proporcionado no es válido' });
  }

  const query = 'UPDATE eventos SET promocion = $1 WHERE id = $2';
  const values = [nuevoEstado, idPromocion];

  client.query(query, values)
    .then(() => {
      res.status(200).json({ mensaje: 'Estado de promoción actualizado correctamente' });
    })
    .catch(err => {
      console.error('Error al cambiar el estado de la promoción:', err);
      res.status(500).send('Error interno del servidor');
    });
});



app.get('/verPromocion', (req, res) => {
    const query = "SELECT id, producto,promocion, detalle FROM eventos where promocion = 'si'";
  
    client.query(query)
      .then(data => {
        res.status(200).json({ eventos: data.rows });
      })
      .catch(err => {
        console.error('Error al obtener los eventos:', err);
        res.status(500).send('Error interno del servidor');
      });
  });

app.delete('/eliminarEvento/:id', async (req, res) => {
    const eventId = req.params.id;
  
    try {
      // Realiza la eliminación en la base de datos
      const result = await client.query('DELETE FROM eventos WHERE id = $1', [eventId]);
  
      if (result.rowCount > 0) {
        res.status(200).json({ message: 'Evento eliminado correctamente' });
      } else {
        res.status(404).json({ message: 'Evento no encontrado' });
      }
    } catch (error) {
      console.error('Error al eliminar evento:', error);
      res.status(500).json({ message: 'Error interno del servidor', error: error.message });
    }
  });
  
app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
  });
  
