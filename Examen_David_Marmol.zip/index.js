document.addEventListener('DOMContentLoaded', () => {
  cargarEventos();
  cargarPromociones();
  verPromociones();

});

async function cargarEventos() {
    try {
      const response = await fetch('http://localhost:3000/verEventos');
      if (!response.ok) {
        throw new Error('Error al obtener los eventos');
      }
  
      const responseData = await response.json();
  
      if (Array.isArray(responseData.eventos)) {
        const tablaBody = document.getElementById('tablaBody');
        tablaBody.innerHTML = ''; // Limpiar la tabla antes de agregar nuevos datos
  
        responseData.eventos.forEach(evento => {
          const row = document.createElement('tr');
          row.innerHTML = `
              <td>${evento.id}</td>
              <td>${evento.nombre}</td>
              <td>${evento.fecha}</td>
              <td>${evento.producto}</td>
              <td>${evento.detalle}</td>
              <td><button onclick="eliminarEvento(${evento.id})">Eliminar</button></td>
          `;
          tablaBody.appendChild(row);
        });
      } else {
        console.error('Los datos obtenidos no contienen un array de eventos:', responseData);
      }
    } catch (error) {
      console.error('Error al cargar eventos:', error);
    }
  }
  
  async function cargarPromociones() {
    try {
      const response = await fetch('http://localhost:3000/verEventos');
      if (!response.ok) {
        throw new Error('Error al obtener los eventos');
      }
  
      const responseData = await response.json();
  
      if (Array.isArray(responseData.eventos)) {
        const tablaBody = document.getElementById('tablaPromociones');
        tablaBody.innerHTML = ''; // Limpiar la tabla antes de agregar nuevos datos
  
        responseData.eventos.forEach(evento => {
          const row = document.createElement('tr');
          row.innerHTML = `
              <td>${evento.id}</td>
              <td>${evento.nombre}</td>
              <td>${evento.producto}</td>
              <td><button onclick="modificarPromocion(${evento.id},'si')">Si</button></td>
              <td><button onclick="modificarPromocion(${evento.id},'no')">No</button></td>
          `;
          tablaBody.appendChild(row);
        });
      } else {
        console.error('Los datos obtenidos no contienen un array de eventos:', responseData);
      }
    } catch (error) {
      console.error('Error al cargar eventos:', error);
    }
  }
  
  function modificarPromocion(idEvento, nuevoEstado) {
    fetch(`http://localhost:3000/cambiarEstadoPromocion/${idEvento}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ estado: nuevoEstado })
    })
    .then(response => {
      console.log(nuevoEstado,response);
      if (!response.ok) {
        throw new Error('Hubo un problema al modificar la promoción.');
      }
      return response.json();
    })
    .then(data => {
      console.log('Promoción modificada correctamente:', data);
      // Aquí podrías realizar alguna acción adicional, como actualizar la interfaz de usuario.
    })
    .catch(error => {
      console.error('Error al modificar la promoción:', error);
      // Aquí podrías manejar el error de alguna manera, como mostrar un mensaje al usuario.
    });
  }
  
  // async function cargarPromociones() {
  //   try {
  //     const response = await fetch('http://localhost:3000/verPromocion');
  //     if (!response.ok) {
  //       throw new Error('Error al obtener promociones');
  //     }
  
  //     const responseData = await response.json();
  
  //     if (Array.isArray(responseData.eventos)) {
  //       const tablaBody = document.getElementById('tablaPromociones');
  //       tablaBody.innerHTML = ''; // Limpiar la tabla antes de agregar nuevos datos
  
  //       responseData.eventos.forEach(evento => {
  //         const row = document.createElement('tr');
  //         row.innerHTML = `
  //             <td>${evento.id}</td>
  //             <td>${evento.producto}</td>
  //             <td>${evento.promocion}</td>
  //         `;
  //         tablaBody.appendChild(row);
  //       });
  //     } else {
  //       console.error('Los datos obtenidos no contienen un array de eventos:', responseData);
  //     }
  //   } catch (error) {
  //     console.error('Error al cargar eventos:', error);
  //   }
    
  // }


  async function verPromociones() {
    try {
      const response = await fetch('http://localhost:3000/verPromocion');
      if (!response.ok) {
        throw new Error('Error al obtener promociones');
      }
  
      const responseData = await response.json();
      console.log(responseData);
      const promotionsContainer = document.getElementById('promotions');
      promotionsContainer.innerHTML = ''; // Limpiar el contenedor antes de agregar nuevas promociones
  
      responseData.eventos.forEach((promocion, index) => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
          <span>${promocion.id}</span>
          <span>${promocion.producto}</span>
          <span>${promocion.detalle}</span>
        `;
        promotionsContainer.appendChild(card);
      });
  
      // Crear una "carta" para las promociones
      const promotionCard = document.createElement('div');
      promotionCard.classList.add('promotion-card');
      promotionsContainer.appendChild(promotionCard);
    } catch (error) {
      console.error('Error al cargar promociones:', error);
    }
  }
  
  
  async function eliminarEvento(id) {
    try {
      const response = await fetch(`http://localhost:3000/eliminarEvento/${id}`, {
        method: 'DELETE',
      });
  
      if (!response.ok) {
        throw new Error(`Error al eliminar evento. Código de respuesta: ${response.status}`);
      }
  
      const data = await response.json();
      console.log(data);
      cargarEventos(); // Actualizar la lista de eventos después de eliminar uno
      cargarPromociones();
    } catch (error) {
      console.error('Error al eliminar evento:', error);
    }
  }

  function enviarEvento() {
    // Obtener los valores de los campos
   
    const nombre = document.getElementById('nombre').value;
    const fecha = document.getElementById('fecha').value;
    const producto = document.getElementById('producto').value;
    const descripcion = document.getElementById('descripcion').value;
    const epromocion = "no";
    // Llamada a la API para enviar un nuevo evento
    fetch('http://localhost:3000/enviarEvento', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ nombre, fecha, producto, descripcion, epromocion }),
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        cargarEventos(); // Actualizar la lista de eventos después de enviar uno nuevo
  
        // Limpiar los campos después de enviar el evento
        document.getElementById('nombre').value = '';
        document.getElementById('fecha').value = '';
        document.getElementById('producto').value = '';
        document.getElementById('descripcion').value = '';
      })
      .catch(error => console.error('Error al enviar evento:', error));
  }
  
  function preguntarIngresarEvento() {
    // Mostrar un cuadro de diálogo de confirmación al usuario
    const nombre = document.getElementById('nombre').value;
    const fecha = document.getElementById('fecha').value;
    const producto = document.getElementById('producto').value;
    const descripcion = document.getElementById('descripcion').value;
    
  
    // Verificar que los campos no estén vacíos
    if (!nombre || !fecha || !producto || !descripcion) {
      alert('Por favor, completa todos los campos.');
      return; // Detener la ejecución de la función si algún campo está vacío
    }
    const confirmacion = confirm('¿Deseas ingresar el evento?');
    // Si el usuario confirma, registra el evento
    if (confirmacion) {
      enviarEvento(); // Llama a la función para enviar el evento
    } else {
      // Si el usuario cancela, no se hace nada
      console.log('El usuario canceló el ingreso del evento.');
    }
  }
  